# CABO — Online Multiplayer Card Game

Real-time multiplayer implementation of the card game Cabo.
2–4 players · WebSockets · Node.js + Socket.io

---

## Quick Start (Local)

### Requirements
- Node.js 16+ (https://nodejs.org)

### Run locally

```bash
# 1. Install dependencies
npm install

# 2. Start the server
npm start

# 3. Open in browser
# http://localhost:3000

# Share your local IP with friends on the same network:
# http://192.168.x.x:3000
```

For local development with auto-reload:
```bash
npm run dev
```

---

## Deploy Online (Free — Railway)

Railway gives you a public URL so anyone on the internet can join.

1. Create a free account at https://railway.app
2. Install the Railway CLI: `npm install -g @railway/cli`
3. From this folder:
```bash
railway login
railway init
railway up
```
4. Railway will give you a URL like `cabo-multiplayer.up.railway.app`
5. Share that URL — anyone can join from anywhere!

---

## Deploy Online (Free — Render)

1. Push this folder to a GitHub repo
2. Go to https://render.com → New → Web Service
3. Connect your repo
4. Settings:
   - Build command: `npm install`
   - Start command: `npm start`
   - Port: `3000`
5. Deploy — Render gives you a free public URL

---

## Deploy Online (Free — Fly.io)

```bash
# Install flyctl: https://fly.io/docs/hands-on/install-flyctl/
fly launch
fly deploy
```

---

## How to Play

### Lobby
1. Enter your name
2. **Create Room** — get a 4-letter room code
3. Share the code with friends
4. Host clicks **Start Game** (min. 2 players)

### Each Round
- You see 2 of your 4 face-down cards at the start (memorise them!)
- On your turn: draw from deck or take the top discard
- Replace one of your cards with the drawn card, or discard it
- Replaced card goes to the discard pile

### Special Cards (when discarded from your hand)
- **7** — Secretly peek at one of your own cards
- **8** — Secretly peek at one opponent's card  
- **9** — Swap one of your cards with an opponent's card

### Reaction Window (4 seconds)
After any discard, all players get a 4-second window to react.
If you have a card matching the **same rank OR same suit** as the discarded card,
you can discard it instantly — even on someone else's turn!
React with no matching card = penalty card added to your hand.

### Jokers
Jokers have no value during play. At round end, each player assigns
their Joker a value (0–13) to minimise their score.

### CABO
Call CABO on your turn if you think you have the lowest score.
The round continues until everyone (including you) has one more turn, then ends.

### Scoring
- Ace = 1 · Cards 2–10 = face value · Jack = 11 · Queen = 12
- Black King = 13 · **Red King = 0** (best card!)
- Penalty cards = 5 each
- If your total reaches exactly 100 → resets to 50
- Game ends when someone reaches 150+ (lowest score wins)

---

## File Structure

```
cabo-multiplayer/
├── server/
│   ├── index.js          # Express + Socket.io server
│   └── gameEngine.js     # Pure game logic (no I/O)
├── public/
│   ├── index.html        # Single-page app shell
│   ├── css/style.css     # All styles
│   └── js/client.js      # Socket.io client + UI rendering
├── package.json
└── README.md
```
