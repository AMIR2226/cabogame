'use strict';
/* global io */

// ─── SOCKET ───────────────────────────────────────────────────────────────────
const socket = io();

// ─── CLIENT STATE ─────────────────────────────────────────────────────────────
let C = {
  roomCode: null,
  myIdx: -1,
  playerName: '',
  state: null,           // latest state snapshot from server
  drawnCard: null,       // only set for current player
  myCards: [],           // [card|null] — locally tracked face-down cards
  myCardVisible: [],     // [bool] — which are currently visible (during peek-start)
  reactionTimer: null,
  reactionDeadline: null,
  peekQueue: [],         // { card, label } to show in sequence
};

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function cardCls(c) {
  if (!c) return 'face-down';
  if (c.isJoker) return 'c-joker';
  if (c.rank === 'K' && (c.suit === '♥' || c.suit === '♦')) return 'c-zero';
  return (c.suit === '♥' || c.suit === '♦') ? 'c-red' : 'c-black';
}
function cardHTML(c) {
  if (!c) return '<div class="card-back-icon">🂠</div>';
  if (c.isJoker) return '<div class="card-val" style="font-size:10px">JOKER</div><div class="card-suit">★</div>';
  return `<div class="card-corner tl">${c.rank}<br>${c.suit}</div><div class="card-val">${c.rank}</div><div class="card-suit">${c.suit}</div><div class="card-corner br">${c.rank}<br>${c.suit}</div>`;
}
function cardVal(c) {
  if (!c || c.isJoker) return '?';
  if (c.rank === 'K') return (c.suit === '♥' || c.suit === '♦') ? 0 : 13;
  const v = {A:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,10:10,J:11,Q:12,K:13};
  return v[c.rank] ?? '?';
}

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}
function showOverlay(id)  { document.getElementById(id).classList.remove('hidden'); }
function hideOverlay(id)  { document.getElementById(id).classList.add('hidden'); }
function setStatus(main, sub='') {
  document.getElementById('status-main').textContent = main;
  document.getElementById('status-sub').textContent  = sub;
}
function setLog(msg) { document.getElementById('game-log').textContent = msg || '—'; }
function showError(msg) {
  const el = document.getElementById('lobby-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

// ─── LOBBY UI ─────────────────────────────────────────────────────────────────
document.getElementById('create-btn').addEventListener('click', () => {
  const name = document.getElementById('player-name').value.trim();
  if (!name) return showError('Enter your name first');
  C.playerName = name;
  socket.emit('create-room', { name }, res => {
    if (res.error) return showError(res.error);
    C.roomCode = res.code;
    C.myIdx    = res.playerIdx;
    document.getElementById('rc-code').textContent = res.code;
    document.getElementById('host-controls').classList.remove('hidden');
    document.getElementById('guest-wait').classList.add('hidden');
    showScreen('waiting-screen');
  });
});

document.getElementById('join-btn').addEventListener('click', () => {
  const name = document.getElementById('player-name').value.trim();
  const code = document.getElementById('room-code-input').value.trim().toUpperCase();
  if (!name) return showError('Enter your name first');
  if (!code || code.length !== 4) return showError('Enter a 4-letter room code');
  C.playerName = name;
  socket.emit('join-room', { name, code }, res => {
    if (res.error) return showError(res.error);
    C.roomCode = res.code;
    C.myIdx    = res.playerIdx;
    document.getElementById('rc-code').textContent = res.code;
    document.getElementById('host-controls').classList.add('hidden');
    document.getElementById('guest-wait').classList.remove('hidden');
    showScreen('waiting-screen');
  });
});

document.getElementById('room-code-input').addEventListener('input', e => {
  e.target.value = e.target.value.toUpperCase();
});

document.getElementById('start-game-btn').addEventListener('click', () => {
  socket.emit('start-game', {}, res => {
    if (res?.error) alert(res.error);
  });
});

// ─── SOCKET EVENTS ────────────────────────────────────────────────────────────
socket.on('state', state => {
  C.state = state;
  C.myIdx = state.myIdx;

  // Sync myCards length
  const me = state.players[C.myIdx];
  if (me && me.cardCount !== C.myCards.length) {
    while (C.myCards.length < me.cardCount) C.myCards.push(null);
    while (C.myCards.length > me.cardCount) C.myCards.pop();
    while (C.myCardVisible.length < me.cardCount) C.myCardVisible.push(false);
    while (C.myCardVisible.length > me.cardCount) C.myCardVisible.pop();
  }
  // Round-end: server sends actual cards
  if (state.phase === 'round-end' || state.phase === 'game-over') {
    if (me?.cards) {
      C.myCards = me.cards.map(c => c || null);
    }
  }

  renderState();
});

socket.on('drawn-card', ({ card }) => {
  C.drawnCard = card;
  renderCenter();
  renderYourZone();
});

socket.on('player-joined', ({ name }) => {
  // Toast-style would be nice; just update waiting list via state
});

socket.on('player-left', ({ name }) => {
  setLog(`${name} disconnected`);
});

socket.on('peek-reveal', ({ card, label }) => {
  enqueuePeek(card, label);
});

// ─── RENDER ───────────────────────────────────────────────────────────────────
function renderState() {
  const s = C.state;
  if (!s) return;

  if (s.phase === 'lobby') { showScreen('waiting-screen'); renderWaiting(); return; }

  showScreen('game-screen');
  renderScoreBar();
  renderOpponents();
  renderCenter();
  renderYourZone();
  renderLog();

  // Phase-specific overlays
  if (s.phase === 'reaction' && s.reactionDeadline) {
    startReactionOverlay(s.reactionCard, s.reactionDeadline);
  } else {
    stopReactionOverlay();
  }

  if (s.phase === 'round-end') renderRoundEnd();
  if (s.phase === 'game-over') renderGameOver();
}

function renderWaiting() {
  const s = C.state;
  if (!s) return;
  const list = document.getElementById('waiting-players');
  list.innerHTML = '';
  for (const p of s.players) {
    const div = document.createElement('div');
    div.className = 'w-player';
    div.innerHTML = `<span class="crown">${p.id === s.players[0].id ? '♚' : '♟'}</span><span>${p.name}</span>`;
    list.appendChild(div);
  }
}

function renderScoreBar() {
  const s = C.state;
  document.getElementById('score-bar').innerHTML = s.players.map((p, i) =>
    `<div class="score-player">
      <div class="score-name">${p.name}${p.id === s.players[0].id ? ' ♚' : ''}</div>
      <div class="score-val ${i === s.currentPlayerIdx ? 'is-turn' : ''} ${!p.connected ? 'disconnected' : ''}">${p.totalScore}</div>
    </div>`
  ).join('');
}

function renderOpponents() {
  const s = C.state;
  const zone = document.getElementById('opponents-zone');
  zone.innerHTML = '';
  for (let i = 0; i < s.players.length; i++) {
    if (i === C.myIdx) continue;
    const p = s.players[i];
    const div = document.createElement('div'); div.className = 'opp-area';
    let lc = 'opp-label';
    if (i === s.currentPlayerIdx) lc += ' is-turn';
    if (s.caboCalledBy === i) lc += ' cabo';
    if (!p.connected) lc += ' disconnected';
    div.innerHTML = `<div class="${lc}">${p.name}${s.caboCalledBy === i ? ' ⚑' : ''}${!p.connected ? ' ✗' : ''}</div>`;
    const row = document.createElement('div'); row.className = 'card-row';
    for (let j = 0; j < p.cardCount; j++) {
      const c = (s.phase === 'round-end' || s.phase === 'game-over') ? p.cards[j] : null;
      const el = makeCard(c, false);
      // Special peek/swap highlighting
      if (needsOppHighlight(i, j)) {
        el.classList.add(s.specialAction?.type === 'swap' ? 'highlight-peek' : 'highlight-peek');
        el.classList.add('clickable');
        el.addEventListener('click', () => handleOppCardClick(i, j));
      }
      row.appendChild(el);
    }
    if (p.penaltyCount > 0) {
      const pen = makeCard(null, false); pen.classList.add('penalty'); row.appendChild(pen);
    }
    div.appendChild(row); zone.appendChild(div);
  }
}

function renderCenter() {
  const s = C.state;
  // Deck
  const dc = document.getElementById('deck-count');
  if (dc) dc.textContent = s.deckSize;
  // Discard
  const disc = document.getElementById('discard-card');
  if (disc) {
    if (s.discardTop) {
      disc.className = 'card ' + cardCls(s.discardTop);
      disc.innerHTML = cardHTML(s.discardTop);
    } else {
      disc.className = 'card face-down'; disc.innerHTML = '';
    }
    // Clickable discard if it's my turn and drawing phase
    const myTurn = s.currentPlayerIdx === C.myIdx;
    if (myTurn && s.phase === 'playing' && s.discardTop) {
      disc.classList.add('clickable');
      disc.onclick = () => socket.emit('draw-discard');
    } else {
      disc.onclick = null;
      disc.classList.remove('clickable');
    }
  }
  // Deck card clickable
  const deckCard = document.getElementById('deck-card');
  const myTurn = s.currentPlayerIdx === C.myIdx;
  if (myTurn && s.phase === 'playing') {
    deckCard.classList.add('clickable');
    deckCard.onclick = () => socket.emit('draw-deck');
  } else {
    deckCard.classList.remove('clickable');
    deckCard.onclick = null;
  }
  // Drawn card
  const dw = document.getElementById('drawn-wrap');
  const dc2 = document.getElementById('drawn-card');
  if (C.drawnCard && s.currentPlayerIdx === C.myIdx) {
    dw.classList.remove('hidden');
    dc2.className = 'card ' + cardCls(C.drawnCard);
    dc2.innerHTML = cardHTML(C.drawnCard);
  } else {
    dw.classList.add('hidden');
    if (!C.drawnCard) dc2.className = 'card face-down';
  }
}

function renderYourZone() {
  const s = C.state;
  if (C.myIdx < 0) return;
  const me = s.players[C.myIdx];
  const yl = document.getElementById('your-label');
  yl.textContent = 'YOU' + (s.caboCalledBy === C.myIdx ? ' ⚑' : '');
  yl.className = 'your-label' +
    (s.currentPlayerIdx === C.myIdx ? ' is-turn' : '') +
    (s.caboCalledBy === C.myIdx ? ' cabo' : '');

  const cr = document.getElementById('your-cards');
  cr.innerHTML = '';
  for (let j = 0; j < me.cardCount; j++) {
    const knownCard = C.myCards[j];
    const visible = C.myCardVisible[j] || (s.phase === 'round-end') || (s.phase === 'game-over');
    const c = visible ? knownCard : null;
    const el = makeCard(c, false);

    // Peek-start: click to peek
    if (s.phase === 'peek-start' && !C.myCardVisible[j] && me.peeksDone < 2) {
      el.classList.add('clickable');
      el.addEventListener('click', () => {
        socket.emit('peek-start', { cardIdx: j }, res => {
          if (res?.error) return;
          C.myCards[j] = res.card;
          C.myCardVisible[j] = true;
          // Auto-hide after 3s
          setTimeout(() => {
            C.myCardVisible[j] = false;
            renderYourZone();
          }, 3000);
          renderYourZone();
        });
      });
    }

    // Replace highlight: if I have a drawn card
    if (C.drawnCard && s.currentPlayerIdx === C.myIdx && (s.phase === 'drawn' || s.phase === 'playing')) {
      el.classList.add('highlight-replace');
      el.addEventListener('click', () => {
        socket.emit('replace-card', { cardIdx: j }, res => {
          if (res?.ok) {
            // Update local card knowledge
            C.myCards[j] = C.drawnCard;
            C.drawnCard = null;
          }
        });
      });
    }

    // Special: peek-self
    if (s.phase === 'special' && s.specialAction?.type === 'peek-self' && s.currentPlayerIdx === C.myIdx) {
      el.classList.add('highlight-swap', 'clickable');
      el.addEventListener('click', () => socket.emit('special-peek-self', { cardIdx: j }));
    }

    // Special: swap pick-own
    if (s.phase === 'special' && s.specialAction?.type === 'swap' &&
        s.specialAction?.stage === 'pick-own' && s.currentPlayerIdx === C.myIdx) {
      el.classList.add('highlight-replace', 'clickable');
      el.addEventListener('click', () => socket.emit('special-swap-own', { cardIdx: j }));
    }

    cr.appendChild(el);
  }
  if (me.penaltyCount > 0) {
    const pen = makeCard(null, false); pen.classList.add('penalty'); cr.appendChild(pen);
  }

  renderActions();
}

function renderActions() {
  const s = C.state;
  const row = document.getElementById('action-row');
  row.innerHTML = '';
  const myTurn = s.currentPlayerIdx === C.myIdx;

  if (s.phase === 'peek-start') {
    const me = s.players[C.myIdx];
    setStatus('PEEK AT 2 CARDS', `Click any face-down card · ${2 - me.peeksDone} left`);
    return;
  }

  if (s.phase === 'playing' && myTurn) {
    setStatus('YOUR TURN', 'Draw from the deck or the discard pile');
    addActionBtn(row, 'DRAW DECK',    () => socket.emit('draw-deck'));
    if (s.discardTop) addActionBtn(row, 'TAKE DISCARD', () => socket.emit('draw-discard'));
    if (!s.caboCalledBy) addActionBtn(row, 'CALL CABO', () => socket.emit('call-cabo'), 'cabo-btn');
    return;
  }

  if ((s.phase === 'drawn' || C.drawnCard) && myTurn) {
    setStatus('CARD DRAWN', 'Click one of your cards to replace it — or discard the drawn card');
    addActionBtn(row, 'DISCARD DRAWN', () => {
      socket.emit('discard-drawn', {}, res => {
        if (res?.ok) C.drawnCard = null;
      });
    });
    return;
  }

  if (s.phase === 'special' && myTurn) {
    const t = s.specialAction?.type;
    if (t === 'peek-self') {
      setStatus('SPECIAL: 7', 'Click one of YOUR cards to secretly peek at it');
      addActionBtn(row, 'SKIP', () => socket.emit('skip-special'));
    } else if (t === 'peek-opp') {
      setStatus('SPECIAL: 8', 'Click an OPPONENT\'S card to peek at it');
      addActionBtn(row, 'SKIP', () => socket.emit('skip-special'));
    } else if (t === 'swap' && s.specialAction?.stage === 'pick-own') {
      setStatus('SPECIAL: 9', 'Click YOUR card to swap...');
    } else if (t === 'swap' && s.specialAction?.stage === 'pick-opp') {
      setStatus('SPECIAL: 9', 'Now click an OPPONENT\'s card to swap with');
    }
    return;
  }

  if (s.phase === 'reaction') {
    setStatus('REACTION WINDOW', 'Open — react if you have a matching card!');
    return;
  }

  if (!myTurn && s.phase === 'playing') {
    const name = s.players[s.currentPlayerIdx]?.name || '';
    setStatus(`${name}'S TURN`, `<span class="dots"><span></span><span></span><span></span></span>`);
    document.getElementById('status-sub').innerHTML = `<span class="dots"><span></span><span></span><span></span></span>`;
    return;
  }

  if (s.phase === 'round-end') {
    setStatus('ROUND OVER', 'See results above');
    return;
  }
}

function renderLog() {
  const s = C.state;
  if (s.log && s.log.length > 0) setLog(s.log[0].msg);
}

// ─── CARD BUILDER ─────────────────────────────────────────────────────────────
function makeCard(card, large = false) {
  const el = document.createElement('div');
  el.className = 'card ' + cardCls(card);
  if (large) { el.style.width = '80px'; el.style.height = '112px'; }
  el.innerHTML = cardHTML(card);
  return el;
}

// ─── SPECIAL HELPERS ─────────────────────────────────────────────────────────
function needsOppHighlight(playerIdx, cardIdx) {
  const s = C.state;
  if (s.currentPlayerIdx !== C.myIdx) return false;
  if (s.phase !== 'special') return false;
  const sa = s.specialAction;
  if (!sa) return false;
  if ((sa.type === 'peek-opp') && playerIdx !== C.myIdx) return true;
  if (sa.type === 'swap' && sa.stage === 'pick-opp' && playerIdx !== C.myIdx) return true;
  return false;
}

function handleOppCardClick(targetPlayerIdx, cardIdx) {
  const s = C.state;
  const sa = s.specialAction;
  if (!sa) return;
  if (sa.type === 'peek-opp') {
    socket.emit('special-peek-opp', { targetPlayerIdx, cardIdx });
  } else if (sa.type === 'swap' && sa.stage === 'pick-opp') {
    socket.emit('special-swap-opp', { targetPlayerIdx, cardIdx }, res => {
      if (res?.ok) {
        // Clear local knowledge of swapped own card
        const ownIdx = sa.ownCardIdx;
        if (ownIdx !== undefined) C.myCards[ownIdx] = null;
      }
    });
  }
}

function addActionBtn(row, label, fn, cls = '') {
  const b = document.createElement('button');
  b.className = 'action-btn ' + cls;
  b.textContent = label;
  b.addEventListener('click', fn);
  row.appendChild(b);
}

// ─── REACTION OVERLAY ────────────────────────────────────────────────────────
let reactionInterval = null;

function startReactionOverlay(card, deadline) {
  if (!card) return;
  const overlay = document.getElementById('react-overlay');
  const bar     = document.getElementById('react-bar');
  const desc    = document.getElementById('react-desc');
  const preview = document.getElementById('react-preview');

  // Rebuild preview card
  preview.innerHTML = '';
  const el = makeCard(card); el.style.margin = '4px auto';
  preview.appendChild(el);
  desc.innerHTML = `Discarded: <strong style="color:var(--gold-light)">${card.rank}${card.suit}</strong> · React if you have a matching rank or suit`;
  overlay.classList.remove('hidden');

  clearInterval(reactionInterval);
  reactionInterval = setInterval(() => {
    const remaining = Math.max(0, deadline - Date.now());
    const total = 4000; // matches server REACTION_MS
    bar.style.width = (remaining / total * 100) + '%';
    if (remaining <= 0) {
      clearInterval(reactionInterval);
      overlay.classList.add('hidden');
    }
  }, 50);

  document.getElementById('react-yes').onclick = () => {
    clearInterval(reactionInterval);
    overlay.classList.add('hidden');
    socket.emit('react', { wantsToReact: true });
  };
  document.getElementById('react-no').onclick = () => {
    clearInterval(reactionInterval);
    overlay.classList.add('hidden');
    socket.emit('react', { wantsToReact: false });
  };
}

function stopReactionOverlay() {
  clearInterval(reactionInterval);
  hideOverlay('react-overlay');
}

// ─── PEEK QUEUE ──────────────────────────────────────────────────────────────
function enqueuePeek(card, label) {
  C.peekQueue.push({ card, label });
  if (C.peekQueue.length === 1) showNextPeek();
}

function showNextPeek() {
  if (!C.peekQueue.length) return;
  const { card, label } = C.peekQueue[0];
  const wrap = document.getElementById('peek-card-wrap');
  wrap.innerHTML = '';
  const el = document.createElement('div');
  el.className = 'peek-large card ' + cardCls(card);
  el.innerHTML = cardHTML(card);
  wrap.appendChild(el);
  document.getElementById('peek-label').textContent = `${label} · Value: ${card.isJoker ? 'WILDCARD' : cardVal(card)}`;
  showOverlay('peek-overlay');
  document.getElementById('peek-ok').onclick = () => {
    hideOverlay('peek-overlay');
    C.peekQueue.shift();
    showNextPeek();
  };
}

// ─── ROUND END ────────────────────────────────────────────────────────────────
function renderRoundEnd() {
  const s = C.state;
  // Check jokers for me
  const myJokers = s.jokerPending?.filter(j => j.playerIdx === C.myIdx) || [];
  if (myJokers.length > 0) {
    showJokerModal(myJokers, 0);
    return;
  }

  const grid = document.getElementById('reveal-grid');
  grid.innerHTML = '';
  for (let i = 0; i < s.players.length; i++) {
    const p = s.players[i];
    const div = document.createElement('div'); div.className = 'reveal-player';
    div.innerHTML = `<div class="reveal-name">${p.name}</div>`;
    const cr = document.createElement('div'); cr.className = 'reveal-cards';
    for (let j = 0; j < p.cardCount; j++) {
      const c = i === C.myIdx ? C.myCards[j] : (p.cards?.[j] || null);
      const el = makeCard(c);
      el.style.cssText += 'width:42px;height:60px;font-size:11px;';
      cr.appendChild(el);
    }
    div.appendChild(cr);
    div.innerHTML += `<div class="reveal-score" id="reveal-score-${i}">—</div>`;
    grid.appendChild(div);
  }

  document.getElementById('round-num').textContent = s.round;
  document.getElementById('round-msg').textContent = 'Waiting for all Joker values...';

  const nb = document.getElementById('next-round-btn');
  const gb = document.getElementById('game-over-btn');
  nb.classList.add('hidden'); gb.classList.add('hidden');

  // Show scores if finalised (jokerPending empty)
  if (!s.jokerPending?.length) {
    showFinalRoundScores();
  }

  showOverlay('round-overlay');
}

function showFinalRoundScores() {
  const s = C.state;
  const table = document.getElementById('score-table');
  table.innerHTML = '<tr><td>PLAYER</td><td>TOTAL</td></tr>' +
    s.players.map((p, i) =>
      `<tr><td>${p.name}${s.caboCalledBy === i ? ' ⚑' : ''}</td><td>${p.totalScore}</td></tr>`
    ).join('');
  const nb = document.getElementById('next-round-btn');
  const gb = document.getElementById('game-over-btn');
  if (s.phase === 'game-over') {
    gb.classList.remove('hidden');
  } else {
    if (s.players[0].id === socket.id) {
      nb.classList.remove('hidden');
      document.getElementById('round-msg').textContent = 'Host: start next round when ready';
    } else {
      document.getElementById('round-msg').textContent = 'Waiting for host to start next round...';
    }
  }
  nb.onclick = () => { hideOverlay('round-overlay'); socket.emit('next-round'); };
  gb.onclick = () => { hideOverlay('round-overlay'); renderGameOver(); };
}

function showJokerModal(jokers, idx) {
  if (idx >= jokers.length) { renderRoundEnd(); return; }
  const grid = document.getElementById('joker-grid'); grid.innerHTML = '';
  for (let v = 0; v <= 13; v++) {
    const b = document.createElement('button'); b.className = 'jval-btn'; b.textContent = v;
    b.onclick = () => {
      socket.emit('assign-joker', { cardIdx: jokers[idx].cardIdx, value: v });
      showJokerModal(jokers, idx + 1);
    };
    grid.appendChild(b);
  }
  hideOverlay('round-overlay');
  showOverlay('joker-overlay');
  // After confirming, hide joker overlay
}

function renderGameOver() {
  const s = C.state;
  const sorted = [...s.players].sort((a, b) => a.totalScore - b.totalScore);
  document.getElementById('gameover-msg').textContent =
    sorted[0].id === socket.id ? '🏆 YOU WIN! Excellent memory.' :
    `${sorted[0].name} wins with ${sorted[0].totalScore} points!`;
  document.getElementById('gameover-table').innerHTML =
    '<tr><td>RANK</td><td>PLAYER</td><td>SCORE</td></tr>' +
    sorted.map((p, i) => `<tr><td>${i+1}</td><td>${p.name}</td><td>${p.totalScore}</td></tr>`).join('');
  hideOverlay('round-overlay');
  hideOverlay('joker-overlay');
  showOverlay('gameover-overlay');
  document.getElementById('play-again-btn').onclick = () => {
    hideOverlay('gameover-overlay');
    location.reload();
  };
}

// ─── GLOBAL KEYBOARD SHORTCUT ─────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    // Close peek modal
    const peek = document.getElementById('peek-overlay');
    if (!peek.classList.contains('hidden')) {
      document.getElementById('peek-ok').click();
    }
  }
});
