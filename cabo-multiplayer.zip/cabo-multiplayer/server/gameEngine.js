'use strict';

// ─── CARD HELPERS ─────────────────────────────────────────────────────────────
const SUITS  = ['♠','♥','♦','♣'];
const RANKS  = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
const VALUES = {A:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,10:10,J:11,Q:12,K:13};
const SPECIALS = {'7':'peek-self','8':'peek-opp','9':'swap'};

function buildDeck() {
  const deck = [];
  for (const suit of SUITS)
    for (const rank of RANKS)
      deck.push({ rank, suit, id: rank + suit });
  deck.push({ rank:'JK', suit:'★', id:'joker1', isJoker:true });
  deck.push({ rank:'JK', suit:'★', id:'joker2', isJoker:true });
  return shuffle(deck);
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function cardValue(c) {
  if (!c || c.isJoker) return 0;
  if (c.rank === 'K') return (c.suit === '♥' || c.suit === '♦') ? 0 : 13;
  return VALUES[c.rank] || 0;
}

function hasSpecial(c) {
  return c && !c.isJoker && SPECIALS[c.rank] ? SPECIALS[c.rank] : null;
}

// ─── ROOM / GAME STATE ────────────────────────────────────────────────────────
function createRoom(roomCode, hostId, hostName) {
  return {
    code: roomCode,
    hostId,
    phase: 'lobby',           // lobby | peek-start | playing | reaction | special | round-end | game-over
    players: [{
      id: hostId,
      name: hostName,
      cards: [],
      penaltyCards: [],
      totalScore: 0,
      peeksDone: 0,
      connected: true,
    }],
    deck: [],
    discardPile: [],
    currentPlayerIdx: 0,
    drawnCard: null,
    drawnFrom: null,
    caboCalledBy: null,       // playerIdx
    caboTurnCount: 0,
    round: 1,
    specialAction: null,      // { type, playerIdx, stage?, ownCardIdx? }
    reactionCard: null,       // card that triggered reaction window
    reactionDeadline: null,   // epoch ms when window closes
    reactionResponded: {},    // socketId -> true/false (responded?)
    jokerPending: [],         // [{playerIdx, cardIdx}] awaiting value assignment
    jokerValues: {},          // playerIdx -> cardIdx -> value
    log: [],
  };
}

// ─── ROUND SETUP ─────────────────────────────────────────────────────────────
function initRound(room) {
  room.deck = buildDeck();
  room.discardPile = [];
  room.drawnCard = null;
  room.drawnFrom = null;
  room.caboCalledBy = null;
  room.caboTurnCount = 0;
  room.specialAction = null;
  room.reactionCard = null;
  room.reactionDeadline = null;
  room.reactionResponded = {};
  room.jokerPending = [];
  room.jokerValues = {};
  room.currentPlayerIdx = 0;
  room.phase = 'peek-start';

  for (const p of room.players) {
    p.cards = [room.deck.pop(), room.deck.pop(), room.deck.pop(), room.deck.pop()];
    p.penaltyCards = [];
    p.peeksDone = 0;
  }
  room.discardPile.push(room.deck.pop());
  addLog(room, `Round ${room.round} started — peek at 2 of your cards`);
}

function addLog(room, msg) {
  room.log.unshift({ msg, ts: Date.now() });
  if (room.log.length > 20) room.log.pop();
}

// ─── SAFE VIEW — strip hidden card data for a specific player ─────────────────
function roomViewFor(room, playerId) {
  const myIdx = room.players.findIndex(p => p.id === playerId);
  return {
    code: room.code,
    phase: room.phase,
    round: room.round,
    currentPlayerIdx: room.currentPlayerIdx,
    caboCalledBy: room.caboCalledBy,
    specialAction: room.specialAction,
    reactionCard: room.reactionCard,
    reactionDeadline: room.reactionDeadline,
    drawnCard: room.drawnCard,        // only sent to current player via separate event
    discardTop: room.discardPile[room.discardPile.length - 1] || null,
    deckSize: room.deck.length,
    discardSize: room.discardPile.length,
    log: room.log.slice(0, 8),
    myIdx,
    players: room.players.map((p, i) => ({
      id: p.id,
      name: p.name,
      totalScore: p.totalScore,
      cardCount: p.cards.length,
      penaltyCount: p.penaltyCards.length,
      connected: p.connected,
      peeksDone: p.peeksDone,
      // Own cards: show face if peeked (during peek-start) or round-end reveal
      cards: p.cards.map((c, ci) => {
        if (i === myIdx) {
          // During peek-start, only reveal cards the player has peeked
          if (room.phase === 'peek-start') return null; // client tracks peeked
          if (room.phase === 'round-end') return c;
          return null; // always hidden during play (client tracks memory)
        }
        // Opponents: only reveal during round-end
        if (room.phase === 'round-end') return c;
        return null;
      }),
    })),
  };
}

// ─── GAME ACTIONS ─────────────────────────────────────────────────────────────

function peekStartCard(room, playerIdx, cardIdx) {
  const p = room.players[playerIdx];
  if (room.phase !== 'peek-start') return err('Not in peek phase');
  if (p.peeksDone >= 2) return err('Already peeked 2 cards');
  if (cardIdx < 0 || cardIdx >= p.cards.length) return err('Invalid card index');
  p.peeksDone++;
  const card = p.cards[cardIdx];
  // Check if all players peeked 2
  if (room.players.every(pl => pl.peeksDone >= 2)) {
    room.phase = 'playing';
    addLog(room, 'All players ready — game begins!');
  }
  return { ok: true, card, peeksDone: p.peeksDone, allReady: room.phase === 'playing' };
}

function drawFromDeck(room, playerIdx) {
  if (!canAct(room, playerIdx)) return err('Not your turn');
  if (room.phase !== 'playing') return err('Wrong phase');
  if (!room.deck.length) reshuffleDeck(room);
  const card = room.deck.pop();
  room.drawnCard = card;
  room.drawnFrom = 'deck';
  room.phase = 'drawn';
  addLog(room, `${room.players[playerIdx].name} drew from deck`);
  return { ok: true };
}

function drawFromDiscard(room, playerIdx) {
  if (!canAct(room, playerIdx)) return err('Not your turn');
  if (room.phase !== 'playing') return err('Wrong phase');
  if (!room.discardPile.length) return err('Discard pile empty');
  const card = room.discardPile.pop();
  room.drawnCard = card;
  room.drawnFrom = 'discard';
  room.phase = 'drawn';
  addLog(room, `${room.players[playerIdx].name} took from discard`);
  return { ok: true };
}

function replaceCard(room, playerIdx, cardIdx) {
  if (!canAct(room, playerIdx)) return err('Not your turn');
  if (room.phase !== 'drawn') return err('No drawn card to place');
  const p = room.players[playerIdx];
  if (cardIdx < 0 || cardIdx >= p.cards.length) return err('Invalid card index');
  const replaced = p.cards[cardIdx];
  p.cards[cardIdx] = room.drawnCard;
  room.discardPile.push(replaced);
  room.drawnCard = null;
  room.drawnFrom = null;
  addLog(room, `${p.name} replaced card ${cardIdx + 1} (discarded ${replaced.rank}${replaced.suit})`);
  const special = hasSpecial(replaced);
  if (special) {
    room.phase = 'special';
    room.specialAction = { type: special, playerIdx, stage: special === 'swap' ? 'pick-own' : null };
    return { ok: true, special, replaced };
  }
  return openReaction(room, replaced);
}

function discardDrawn(room, playerIdx) {
  if (!canAct(room, playerIdx)) return err('Not your turn');
  if (room.phase !== 'drawn') return err('No drawn card');
  const card = room.drawnCard;
  room.discardPile.push(card);
  room.drawnCard = null;
  room.drawnFrom = null;
  addLog(room, `${room.players[playerIdx].name} discarded drawn ${card.rank}${card.suit}`);
  return openReaction(room, card);
}

function callCabo(room, playerIdx) {
  if (!canAct(room, playerIdx)) return err('Not your turn');
  if (room.caboCalledBy !== null) return err('CABO already called');
  room.caboCalledBy = playerIdx;
  room.caboTurnCount = 0;
  addLog(room, `⚑ ${room.players[playerIdx].name} called CABO!`);
  return advanceTurn(room);
}

// ─── SPECIAL ACTIONS ─────────────────────────────────────────────────────────

function specialPeekSelf(room, playerIdx, cardIdx) {
  if (!isSpecialTurn(room, playerIdx, 'peek-self')) return err('Not your special turn');
  const card = room.players[playerIdx].cards[cardIdx];
  room.specialAction = null;
  addLog(room, `${room.players[playerIdx].name} peeked at their own card`);
  return { ok: true, card, done: true, ...advanceTurn(room) };
}

function specialPeekOpp(room, playerIdx, targetPlayerIdx, cardIdx) {
  if (!isSpecialTurn(room, playerIdx, 'peek-opp')) return err('Not your special turn');
  if (targetPlayerIdx === playerIdx) return err('Cannot peek your own card with 8');
  const card = room.players[targetPlayerIdx].cards[cardIdx];
  room.specialAction = null;
  addLog(room, `${room.players[playerIdx].name} peeked at ${room.players[targetPlayerIdx].name}'s card`);
  return { ok: true, card, targetPlayerIdx, cardIdx, done: true, ...advanceTurn(room) };
}

function specialSwapPickOwn(room, playerIdx, cardIdx) {
  if (!isSpecialTurn(room, playerIdx, 'swap')) return err('Not your special turn');
  if (room.specialAction.stage !== 'pick-own') return err('Wrong swap stage');
  room.specialAction.stage = 'pick-opp';
  room.specialAction.ownCardIdx = cardIdx;
  return { ok: true };
}

function specialSwapPickOpp(room, playerIdx, targetPlayerIdx, cardIdx) {
  if (!isSpecialTurn(room, playerIdx, 'swap')) return err('Not your special turn');
  if (room.specialAction.stage !== 'pick-opp') return err('Wrong swap stage');
  if (targetPlayerIdx === playerIdx) return err('Cannot swap with yourself');
  const ownIdx = room.specialAction.ownCardIdx;
  const tmp = room.players[playerIdx].cards[ownIdx];
  room.players[playerIdx].cards[ownIdx] = room.players[targetPlayerIdx].cards[cardIdx];
  room.players[targetPlayerIdx].cards[cardIdx] = tmp;
  room.specialAction = null;
  addLog(room, `${room.players[playerIdx].name} swapped card ${ownIdx+1} with ${room.players[targetPlayerIdx].name}'s card ${cardIdx+1}`);
  return { ok: true, done: true, ...advanceTurn(room) };
}

function skipSpecial(room, playerIdx) {
  if (!isSpecialTurn(room, playerIdx, room.specialAction?.type)) return err('Not your special turn');
  room.specialAction = null;
  addLog(room, `${room.players[playerIdx].name} skipped special ability`);
  return { ok: true, ...advanceTurn(room) };
}

// ─── REACTION ────────────────────────────────────────────────────────────────
const REACTION_MS = 4000;

function openReaction(room, card) {
  room.phase = 'reaction';
  room.reactionCard = card;
  room.reactionDeadline = Date.now() + REACTION_MS;
  room.reactionResponded = {};
  return { ok: true, reactionCard: card, deadline: room.reactionDeadline };
}

function respondReaction(room, playerId, playerIdx, wantsToReact) {
  if (room.phase !== 'reaction') return err('No reaction window');
  if (room.reactionResponded[playerId]) return err('Already responded');
  room.reactionResponded[playerId] = true;

  if (wantsToReact) {
    const p = room.players[playerIdx];
    const top = room.reactionCard;
    const match = p.cards.findIndex(c => c && !c.isJoker && (c.rank === top.rank || c.suit === top.suit));
    if (match === -1) {
      // Penalty
      if (room.deck.length) p.penaltyCards.push(room.deck.pop());
      addLog(room, `${p.name} tried to react — no match! Penalty card.`);
    } else {
      const reacted = p.cards.splice(match, 1)[0];
      room.discardPile.push(reacted);
      addLog(room, `${p.name} reacted! Discarded ${reacted.rank}${reacted.suit}`);
    }
  }

  // Check if all players responded
  const allResponded = room.players.every(p => room.reactionResponded[p.id]);
  if (allResponded || Date.now() >= room.reactionDeadline) {
    return closeReaction(room);
  }
  return { ok: true, waiting: true };
}

function closeReaction(room) {
  room.reactionCard = null;
  room.reactionDeadline = null;
  room.reactionResponded = {};
  return advanceTurn(room);
}

// ─── TURN ADVANCE ─────────────────────────────────────────────────────────────
function advanceTurn(room) {
  room.drawnCard = null;
  room.drawnFrom = null;

  if (room.caboCalledBy !== null) {
    room.caboTurnCount++;
    if (room.caboTurnCount >= room.players.length) {
      return startRoundEnd(room);
    }
  }

  room.currentPlayerIdx = (room.currentPlayerIdx + 1) % room.players.length;
  room.phase = 'playing';
  addLog(room, `${room.players[room.currentPlayerIdx].name}'s turn`);
  return { ok: true, turnAdvanced: true };
}

// ─── ROUND END / SCORING ─────────────────────────────────────────────────────
function startRoundEnd(room) {
  room.phase = 'round-end';
  room.jokerPending = [];
  for (let i = 0; i < room.players.length; i++)
    for (let j = 0; j < room.players[i].cards.length; j++)
      if (room.players[i].cards[j].isJoker)
        room.jokerPending.push({ playerIdx: i, cardIdx: j });
  addLog(room, 'Round over — assigning Joker values...');
  return { ok: true, roundEnd: true };
}

function assignJokerValue(room, playerIdx, cardIdx, value) {
  if (!room.jokerPending.find(j => j.playerIdx === playerIdx && j.cardIdx === cardIdx))
    return err('No joker pending for that slot');
  if (!room.jokerValues[playerIdx]) room.jokerValues[playerIdx] = {};
  room.jokerValues[playerIdx][cardIdx] = value;
  room.jokerPending = room.jokerPending.filter(j => !(j.playerIdx === playerIdx && j.cardIdx === cardIdx));
  if (room.jokerPending.length === 0) return finaliseScores(room);
  return { ok: true, waiting: true };
}

function finaliseScores(room) {
  const roundScores = room.players.map((p, i) => {
    let s = 0;
    for (let j = 0; j < p.cards.length; j++) {
      const c = p.cards[j];
      if (!c) continue;
      if (c.isJoker) s += (room.jokerValues[i]?.[j] ?? 0);
      else s += cardValue(c);
    }
    s += p.penaltyCards.length * 5;
    return s;
  });

  for (let i = 0; i < room.players.length; i++) {
    room.players[i].totalScore += roundScores[i];
    if (room.players[i].totalScore === 100) room.players[i].totalScore = 50;
  }

  const allCards = room.players.map(p => [...p.cards]);
  const gameOver = room.players.some(p => p.totalScore >= 150) || room.round >= 6;
  room.phase = gameOver ? 'game-over' : 'round-end';

  addLog(room, `Scores: ` + room.players.map((p,i) => `${p.name} +${roundScores[i]}`).join(', '));
  return { ok: true, roundScores, allCards, gameOver };
}

function startNextRound(room) {
  room.round++;
  initRound(room);
  return { ok: true };
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function canAct(room, playerIdx) {
  return room.currentPlayerIdx === playerIdx &&
    (room.phase === 'playing' || room.phase === 'drawn');
}

function isSpecialTurn(room, playerIdx, type) {
  return room.phase === 'special' &&
    room.specialAction?.playerIdx === playerIdx &&
    room.specialAction?.type === type;
}

function reshuffleDeck(room) {
  const top = room.discardPile.pop();
  room.deck = shuffle([...room.discardPile]);
  room.discardPile = top ? [top] : [];
  addLog(room, 'Deck reshuffled from discard pile');
}

function err(msg) { return { ok: false, error: msg }; }

module.exports = {
  createRoom, initRound, roomViewFor, cardValue, hasSpecial,
  peekStartCard, drawFromDeck, drawFromDiscard, replaceCard, discardDrawn, callCabo,
  specialPeekSelf, specialPeekOpp, specialSwapPickOwn, specialSwapPickOpp, skipSpecial,
  respondReaction, closeReaction, assignJokerValue, finaliseScores, startNextRound,
  REACTION_MS,
};
