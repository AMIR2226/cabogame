'use strict';

const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const path       = require('path');
const { v4: uuidv4 } = require('uuid');

const G = require('./gameEngine');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: '*' },
  pingTimeout: 30000,
  pingInterval: 10000,
});

const PORT = process.env.PORT || 3000;

// ─── STATIC FILES ────────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '../public')));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '../public/index.html')));

// ─── ROOM STORE ───────────────────────────────────────────────────────────────
const rooms   = new Map();   // code -> room
const players = new Map();   // socketId -> { roomCode, playerIdx, playerId }

function generateCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return rooms.has(code) ? generateCode() : code;
}

function broadcast(room) {
  for (const p of room.players) {
    const sock = io.sockets.sockets.get(p.id);
    if (sock) {
      const view = G.roomViewFor(room, p.id);
      // Send drawn card only to the current player
      if (room.drawnCard && room.players[room.currentPlayerIdx].id === p.id) {
        view.drawnCard = room.drawnCard;
      } else {
        view.drawnCard = null;
      }
      sock.emit('state', view);
    }
  }
}

function broadcastToRoom(roomCode, event, data) {
  io.to(roomCode).emit(event, data);
}

// ─── REACTION TIMEOUT ────────────────────────────────────────────────────────
const reactionTimers = new Map(); // roomCode -> timeout handle

function startReactionTimer(room) {
  clearReactionTimer(room.code);
  const handle = setTimeout(() => {
    if (!rooms.has(room.code)) return;
    const r = rooms.get(room.code);
    if (r.phase !== 'reaction') return;
    const result = G.closeReaction(r);
    handleRoundEndIfNeeded(r, result);
    broadcast(r);
  }, G.REACTION_MS + 500); // +500ms grace
  reactionTimers.set(room.code, handle);
}

function clearReactionTimer(code) {
  if (reactionTimers.has(code)) {
    clearTimeout(reactionTimers.get(code));
    reactionTimers.delete(code);
  }
}

function handleRoundEndIfNeeded(room, result) {
  if (result.roundEnd) {
    // Auto-assign jokers for all players (server side, then finalise)
    for (const jk of [...room.jokerPending]) {
      const est = estimateScore(room, jk.playerIdx);
      G.assignJokerValue(room, jk.playerIdx, jk.cardIdx, est < 15 ? 0 : 13);
    }
    if (room.jokerPending.length === 0) G.finaliseScores(room);
    broadcast(room);
  }
}

function estimateScore(room, playerIdx) {
  return room.players[playerIdx].cards.reduce((s, c) => s + G.cardValue(c), 0);
}

// ─── SOCKET EVENTS ───────────────────────────────────────────────────────────
io.on('connection', socket => {
  console.log('connect', socket.id);

  // ── CREATE ROOM ──────────────────────────────────────────────────────────
  socket.on('create-room', ({ name }, cb) => {
    if (!name || typeof name !== 'string') return cb({ error: 'Name required' });
    const code   = generateCode();
    const playerId = socket.id;
    const room   = G.createRoom(code, playerId, name.slice(0, 16));
    rooms.set(code, room);
    players.set(socket.id, { roomCode: code, playerIdx: 0, playerId });
    socket.join(code);
    console.log(`Room ${code} created by ${name}`);
    cb({ ok: true, code, playerIdx: 0 });
    broadcast(room);
  });

  // ── JOIN ROOM ─────────────────────────────────────────────────────────────
  socket.on('join-room', ({ code, name }, cb) => {
    if (!name || !code) return cb({ error: 'Name and code required' });
    const room = rooms.get(code.toUpperCase());
    if (!room) return cb({ error: 'Room not found' });
    if (room.phase !== 'lobby') return cb({ error: 'Game already in progress' });
    if (room.players.length >= 4) return cb({ error: 'Room full (max 4 players)' });
    if (room.players.find(p => p.name.toLowerCase() === name.toLowerCase()))
      return cb({ error: 'Name already taken in this room' });

    const playerIdx = room.players.length;
    room.players.push({
      id: socket.id,
      name: name.slice(0, 16),
      cards: [],
      penaltyCards: [],
      totalScore: 0,
      peeksDone: 0,
      connected: true,
    });
    players.set(socket.id, { roomCode: code, playerIdx, playerId: socket.id });
    socket.join(code);
    console.log(`${name} joined room ${code}`);
    cb({ ok: true, code, playerIdx });
    broadcast(room);
    broadcastToRoom(code, 'player-joined', { name });
  });

  // ── START GAME ────────────────────────────────────────────────────────────
  socket.on('start-game', (_, cb) => {
    const info = players.get(socket.id);
    if (!info) return cb?.({ error: 'Not in a room' });
    const room = rooms.get(info.roomCode);
    if (!room) return cb?.({ error: 'Room gone' });
    if (room.players[0].id !== socket.id) return cb?.({ error: 'Only host can start' });
    if (room.players.length < 2) return cb?.({ error: 'Need at least 2 players' });
    if (room.phase !== 'lobby') return cb?.({ error: 'Already started' });
    G.initRound(room);
    broadcast(room);
    cb?.({ ok: true });
  });

  // ── PEEK START ────────────────────────────────────────────────────────────
  socket.on('peek-start', ({ cardIdx }, cb) => {
    const info = players.get(socket.id);
    if (!info) return cb?.({ error: 'Not in room' });
    const room = rooms.get(info.roomCode);
    if (!room || room.phase !== 'peek-start') return cb?.({ error: 'Wrong phase' });
    const result = G.peekStartCard(room, info.playerIdx, cardIdx);
    if (!result.ok) return cb?.({ error: result.error });
    cb?.({ ok: true, card: result.card, peeksDone: result.peeksDone });
    broadcast(room);
  });

  // ── DRAW ──────────────────────────────────────────────────────────────────
  socket.on('draw-deck', (_, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.drawFromDeck(room, info.playerIdx);
    if (!result.ok) return cb?.({ error: result.error });
    // Send drawn card only to this player
    socket.emit('drawn-card', { card: room.drawnCard });
    broadcast(room);
    cb?.({ ok: true });
  });

  socket.on('draw-discard', (_, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.drawFromDiscard(room, info.playerIdx);
    if (!result.ok) return cb?.({ error: result.error });
    socket.emit('drawn-card', { card: room.drawnCard });
    broadcast(room);
    cb?.({ ok: true });
  });

  // ── REPLACE / DISCARD DRAWN ───────────────────────────────────────────────
  socket.on('replace-card', ({ cardIdx }, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.replaceCard(room, info.playerIdx, cardIdx);
    if (!result.ok) return cb?.({ error: result.error });
    if (result.reactionCard) startReactionTimer(room);
    broadcast(room);
    cb?.({ ok: true });
  });

  socket.on('discard-drawn', (_, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.discardDrawn(room, info.playerIdx);
    if (!result.ok) return cb?.({ error: result.error });
    if (result.reactionCard) startReactionTimer(room);
    broadcast(room);
    cb?.({ ok: true });
  });

  // ── CABO ─────────────────────────────────────────────────────────────────
  socket.on('call-cabo', (_, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.callCabo(room, info.playerIdx);
    if (!result.ok) return cb?.({ error: result.error });
    handleRoundEndIfNeeded(room, result);
    broadcast(room);
    cb?.({ ok: true });
  });

  // ── REACTION ─────────────────────────────────────────────────────────────
  socket.on('react', ({ wantsToReact }, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.respondReaction(room, socket.id, info.playerIdx, wantsToReact);
    if (!result.ok) return cb?.({ error: result.error });
    if (!result.waiting) {
      clearReactionTimer(room.code);
      handleRoundEndIfNeeded(room, result);
    }
    broadcast(room);
    cb?.({ ok: true });
  });

  // ── SPECIALS ──────────────────────────────────────────────────────────────
  socket.on('special-peek-self', ({ cardIdx }, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.specialPeekSelf(room, info.playerIdx, cardIdx);
    if (!result.ok) return cb?.({ error: result.error });
    socket.emit('peek-reveal', { card: result.card, label: `Your card ${cardIdx+1}` });
    broadcast(room);
    cb?.({ ok: true });
  });

  socket.on('special-peek-opp', ({ targetPlayerIdx, cardIdx }, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.specialPeekOpp(room, info.playerIdx, targetPlayerIdx, cardIdx);
    if (!result.ok) return cb?.({ error: result.error });
    socket.emit('peek-reveal', { card: result.card, label: `${room.players[targetPlayerIdx].name}'s card ${cardIdx+1}` });
    broadcast(room);
    cb?.({ ok: true });
  });

  socket.on('special-swap-own', ({ cardIdx }, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.specialSwapPickOwn(room, info.playerIdx, cardIdx);
    if (!result.ok) return cb?.({ error: result.error });
    broadcast(room);
    cb?.({ ok: true });
  });

  socket.on('special-swap-opp', ({ targetPlayerIdx, cardIdx }, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.specialSwapPickOpp(room, info.playerIdx, targetPlayerIdx, cardIdx);
    if (!result.ok) return cb?.({ error: result.error });
    broadcast(room);
    cb?.({ ok: true });
  });

  socket.on('skip-special', (_, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.skipSpecial(room, info.playerIdx);
    if (!result.ok) return cb?.({ error: result.error });
    broadcast(room);
    cb?.({ ok: true });
  });

  // ── JOKER VALUE ───────────────────────────────────────────────────────────
  socket.on('assign-joker', ({ cardIdx, value }, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    const result = G.assignJokerValue(room, info.playerIdx, cardIdx, value);
    if (!result.ok) return cb?.({ error: result.error });
    if (result.roundScores) {
      // Scores finalised
      broadcast(room);
    }
    cb?.({ ok: true });
  });

  // ── NEXT ROUND ────────────────────────────────────────────────────────────
  socket.on('next-round', (_, cb) => {
    const { room, info, error } = getRoom(socket);
    if (error) return cb?.({ error });
    if (room.players[0].id !== socket.id) return cb?.({ error: 'Only host starts next round' });
    if (room.phase !== 'round-end') return cb?.({ error: 'Not round-end phase' });
    G.startNextRound(room);
    broadcast(room);
    cb?.({ ok: true });
  });

  // ── DISCONNECT ────────────────────────────────────────────────────────────
  socket.on('disconnect', () => {
    const info = players.get(socket.id);
    if (!info) return;
    const room = rooms.get(info.roomCode);
    if (room) {
      const p = room.players.find(p => p.id === socket.id);
      if (p) {
        p.connected = false;
        broadcastToRoom(info.roomCode, 'player-left', { name: p.name });
        broadcast(room);
      }
      // Clean up empty rooms after delay
      setTimeout(() => {
        const r = rooms.get(info.roomCode);
        if (r && r.players.every(p => !p.connected)) {
          rooms.delete(info.roomCode);
          clearReactionTimer(info.roomCode);
          console.log(`Room ${info.roomCode} cleaned up`);
        }
      }, 60000);
    }
    players.delete(socket.id);
    console.log('disconnect', socket.id);
  });
});

// ─── HELPER ───────────────────────────────────────────────────────────────────
function getRoom(socket) {
  const info = players.get(socket.id);
  if (!info) return { error: 'Not in a room' };
  const room = rooms.get(info.roomCode);
  if (!room) return { error: 'Room not found' };
  return { room, info };
}

server.listen(PORT, () => {
  console.log(`\n🃏 Cabo server running on http://localhost:${PORT}\n`);
});
